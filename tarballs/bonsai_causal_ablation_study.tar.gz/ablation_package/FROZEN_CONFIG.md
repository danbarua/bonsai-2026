# FROZEN CONFIGURATION — no changes below this point until full-test-set
# results are in. Per code review: threshold changes, feature additions,
# calibration changes, or inspection-driven fixes are NOT permitted before
# this run completes.

Reference topologies: class_topologies_200.pkl
  - 200 images/class, indices [0:200] per class from MNIST train split
  - population_developmental_stat, threshold=0.9, background-background
    pairs excluded

Calibration baselines: baselines_both_modes.pkl
  - 200 images, randomly drawn (rng seed=555) from the FULL 60,000-image
    train split, NOT deliberately deduplicated against the topology
    images above -- expected overlap ~6-7 images by chance
    (200 * 2000/60000 ~= 6.67). NOT controlled for. Disclosed, not fixed,
    per the freeze.
  - Both 'simple' and 'cosine' scoring modes baselined separately

Hybrid classifier head: trained on hybrid_20feat_batch1.pkl +
hybrid_20feat_batch2.pkl (concatenated)
  - 300 images/class, indices [200:500] per class from MNIST train split
    -- disjoint from the topology-construction range [0:200]
  - 20 features per image (10 classes x {simple, cosine} z-scored score)
  - sklearn.linear_model.LogisticRegression, default solver (lbfgs --
    GRADIENT-BASED, quasi-Newton; NOT a closed-form or Hebbian update)

Total distinct training images: 2000 (topology) + 3000 (hybrid head) = 5000
Calibration images (200) are a separate pool, drawn from the same train
split, with unquantified small overlap with the topology set as noted above.

Evaluation to date: 200-image stratified sample from the MNIST TEST split
(rng seed=999), reused repeatedly across every design decision in this
investigation. Functions as a VALIDATION set, not a held-out test set,
per the review's correct characterization. 94.0% on this sample is the
number obtained; it is NOT yet validated against the full test set.

NEXT STEP: full 10,000-image MNIST test set, run once, unchanged
configuration, no cherry-picking or fixes based on the outcome.
