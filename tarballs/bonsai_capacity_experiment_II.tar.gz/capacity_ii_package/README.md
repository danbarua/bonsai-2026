# Capacity Experiment II: Degree-Aware / Graph-Smoothness Readout

Findings: bonsai_capacity_experiment_II_findings.md

Key results:
- 10D graph smoothness (x^T L x against each class's Laplacian) alone
  reaches 70.2% accuracy -- confirmed as a genuinely different, real
  signal, not noise.
- Combining smoothness with the original 20D readout (30D total) again
  fails to beat generic dimensionality controls -- the same pattern as
  Capacity Experiment I, now with a functional confirmed different on its
  own terms.
- Smoothness alone shows the highest correlation with an independent
  MLP's confusion pattern of any condition tested (rho=0.829), though
  this does not persist in the 30D combination.

Next candidates per the reviewer's ranking: spectral projections,
community statistics -- Capacity Experiment III.
