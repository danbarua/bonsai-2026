# ARCHIVED, UNVERIFIED -- DO NOT USE AS EVIDENCE

These files (60D notMNIST multi-threshold artifacts: 0.85/0.90/0.95
thresholds) were discovered on disk with unclear provenance. Their
combined-representation result (a reported catastrophic collapse to
36% accuracy) FAILED to reproduce in an independent, from-scratch
verification -- see /mnt/user-data/outputs/bonsai_notmnist_capacity_VERIFIED.md
for the full verification and the correct, trustworthy result (84.0%,
no collapse).

The topology-construction step in these files was confirmed correct
(bit-identical to a fresh rebuild). Something in how the training/test
features were built or combined here does not match the current
verified pipeline's behavior, for reasons not yet identified. Kept for
potential future investigation into what actually happened, not as
scientific evidence for anything.

Archived (not deleted) per explicit reviewer recommendation:
"Future-you may eventually identify exactly what differed."
