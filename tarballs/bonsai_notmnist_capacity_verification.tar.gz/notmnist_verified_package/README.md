# notMNIST Capacity Experiment: Verification and Retraction

Read bonsai_notmnist_capacity_VERIFIED.md first -- it is the trustworthy
result. bonsai_notmnist_archived_artefacts_preliminary.md is kept for the
record but describes a finding that did NOT reproduce and should not be
cited as evidence.

Headline: a from-scratch rebuild, using zero mystery-provenance files,
gives 84.0% for the real 40D (0.90+0.95) combination -- a modest genuine
improvement over the 20D baseline (80.4%), not the catastrophic collapse
to 36% originally reported from unverified archived artifacts. That
earlier result is retracted.
