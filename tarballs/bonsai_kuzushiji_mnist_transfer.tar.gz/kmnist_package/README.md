# Kuzushiji-MNIST Transfer Experiment (Second Transfer Target)

Data: the canonical host (codh.rois.ac.jp) is not reachable from typical
sandboxed environments -- obtain the four IDX files via the official
rois-codh/kmnist repository's instructions and provide them directly, or
use torchvision.datasets.KMNIST / tensorflow_datasets if available.

Pipeline code is identical to the frozen MNIST/Fashion-MNIST
configuration (developmental_pruning.py, topology_matching_classifier.py).
mantel_test_and_mlp_comparison.py has the reusable Mantel test and MLP
baseline code, unchanged from the Fashion-MNIST package.

See bonsai_kuzushiji_mnist_findings.md for the full results -- this is the
"boundary" experiment: the topology-overlap-predicts-confusion phenomenon
found on Fashion-MNIST does not replicate with the same strength here,
an informative negative result, not a failure to reproduce.
