"""
General weighted-graph coupled-oscillator simulator. Unlike
LocalOscillatorField (fixed 4-neighbor pixel grid, always the same
regardless of class), this accepts an arbitrary weighted adjacency
matrix as the coupling structure -- the learned topology, or any control
graph, has never been used as a coupling structure for dynamics before
this. Built specifically for Stage 0/Stage 1 graph-dynamics
characterization, not for image encoding (no input-anchoring bias term;
pure coupling dynamics only).
"""
import numpy as np


class GraphOscillatorField:
    def __init__(self, W, dt=0.05, k_coupling=1.0, seed=None):
        """W: (n,n) symmetric non-negative weighted adjacency matrix over
        the ACTIVE node set only (isolated nodes excluded before
        construction, matching the convention established throughout this
        project's spectral work)."""
        self.n = W.shape[0]
        self.W = W
        self.dt = dt
        self.k_coupling = k_coupling
        rng = np.random.default_rng(seed)
        self.phases = rng.uniform(0, 2 * np.pi, self.n)

    def set_phases(self, phases):
        self.phases = phases.copy()

    def _coupling_force(self, phases):
        # dtheta_i/dt = k_coupling * sum_j W_ij sin(theta_j - theta_i)
        diff = phases[None, :] - phases[:, None]  # diff[i,j] = theta_j - theta_i
        return self.k_coupling * np.sum(self.W * np.sin(diff), axis=1)

    def step(self):
        dtheta = self._coupling_force(self.phases)
        self.phases = (self.phases + self.dt * dtheta) % (2 * np.pi)
        return self.phases

    def run(self, steps, record_every=1):
        history = []
        for i in range(steps):
            self.step()
            if i % record_every == 0:
                history.append(self.phases.copy())
        return history

    def find_equilibrium(self, steps=2000, seed=0, convergence_tol=1e-8, check_every=50):
        """Run from a random initial condition until the coupling force
        norm drops below convergence_tol, or steps is reached. Returns
        (equilibrium_phases, converged_bool, steps_taken)."""
        rng = np.random.default_rng(seed)
        self.phases = rng.uniform(0, 2 * np.pi, self.n)
        for t in range(steps):
            force = self._coupling_force(self.phases)
            self.phases = (self.phases + self.dt * force) % (2 * np.pi)
            if (t + 1) % check_every == 0:
                if np.max(np.abs(force)) < convergence_tol:
                    return self.phases.copy(), True, t + 1
        force = self._coupling_force(self.phases)
        return self.phases.copy(), np.max(np.abs(force)) < convergence_tol, steps

    def jacobian_at(self, phases):
        """J_ij = -d(dtheta_i/dt)/d(theta_j) at the given phase
        configuration, for the linearized dynamics ddelta/dt = -J delta
        near equilibrium."""
        diff = phases[None, :] - phases[:, None]  # diff[i,j] = theta_j - theta_i
        off_diag = -self.k_coupling * self.W * np.cos(diff)
        J = off_diag.copy()
        np.fill_diagonal(J, -np.sum(off_diag, axis=1))
        return J


def find_equilibrium_lbfgs(W, k_coupling=1.0, seed=0, pin_node=0):
    """Fast equilibrium finding via L-BFGS on the Kuramoto potential
    V(theta) = -k_coupling * sum_{i<j} W_ij cos(theta_i - theta_j),
    with one node's phase pinned to remove the global rotational zero
    mode. Much faster than explicit Euler for graphs with a small
    spectral gap, where Euler needs many steps to resolve the slow mode."""
    from scipy.optimize import minimize
    n = W.shape[0]
    rng = np.random.default_rng(seed)
    theta0 = rng.uniform(0, 2 * np.pi, n)
    free_idx = [i for i in range(n) if i != pin_node]

    def potential_and_grad(theta_free):
        theta = np.zeros(n)
        theta[free_idx] = theta_free
        theta[pin_node] = 0.0
        diff = theta[None, :] - theta[:, None]
        V = -k_coupling * 0.5 * np.sum(W * np.cos(diff))
        # gradient: dV/dtheta_i = k_coupling * sum_j W_ij sin(theta_i - theta_j)
        grad_full = k_coupling * np.sum(W * np.sin(theta[:, None] - theta[None, :]), axis=1)
        return V, grad_full[free_idx]

    result = minimize(potential_and_grad, theta0[free_idx], jac=True, method='L-BFGS-B',
                       options={'maxiter': 5000, 'ftol': 1e-15, 'gtol': 1e-12})
    theta_final = np.zeros(n)
    theta_final[free_idx] = result.x
    theta_final[pin_node] = 0.0
    return theta_final % (2 * np.pi), result


def gauge_corrected_distance(theta_a, theta_b):
    """D = mean squared circular distance between theta_a and theta_b,
    minimized over a global phase offset -- removes the neutral global
    rotation mode so genuine relative-phase separation is measured, not
    harmless collective rotation."""
    shift = np.angle(np.mean(np.exp(1j * (theta_a - theta_b))))
    diff = np.angle(np.exp(1j * (theta_a - theta_b - shift)))
    return np.mean(diff ** 2)


def paired_trajectory_response(W, theta0, perturb_node, epsilon, steps, dt=0.05, k_coupling=1.0, record_every=1):
    """Runs baseline (from theta0) and perturbed (from theta0 with
    perturb_node displaced by epsilon) trajectories in lockstep from the
    SAME initial condition, returns the gauge-corrected distance D(t) at
    each recorded step. Sidesteps any need to identify 'the' equilibrium
    -- valid regardless of how many attractors the graph supports."""
    base = GraphOscillatorField(W, dt=dt, k_coupling=k_coupling)
    base.set_phases(theta0)
    pert = GraphOscillatorField(W, dt=dt, k_coupling=k_coupling)
    theta0_pert = theta0.copy()
    theta0_pert[perturb_node] = (theta0_pert[perturb_node] + epsilon) % (2 * np.pi)
    pert.set_phases(theta0_pert)

    D_history = [gauge_corrected_distance(pert.phases, base.phases)]
    for i in range(steps):
        base.step()
        pert.step()
        if (i + 1) % record_every == 0:
            D_history.append(gauge_corrected_distance(pert.phases, base.phases))
    return np.array(D_history)
