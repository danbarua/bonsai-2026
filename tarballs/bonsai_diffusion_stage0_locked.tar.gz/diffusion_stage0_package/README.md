# Diffusion Stage 0: Properly Calibrated, Still Provisional

Findings: bonsai_diffusion_stage0_locked_design.md

STATUS: Calibration panel complete (3 classes x 3 degree-stratified nodes
x 4 constructions = 36 cases). Design is a CANDIDATE, not locked -- final
decision on window/epsilon still needs sign-off given how short the
achievable window turned out to be.

KEY RESULT: none of the prespecified epsilon grid {0.2, 0.1, 0.05, 0.025}
reaches the full 50-step target window under the strict rule. Best
achievable: epsilon=0.025, window=steps 1-13 (vs the earlier single-node
estimate of steps 1-8 at epsilon=0.2 -- that estimate is now superseded).

Numerical signal confirmed adequate at epsilon=0.025 (D(0) ~1e-6, ~10
orders of magnitude above float64 precision).

This is the reviewer's own anticipated "third branch": the four graph
families have genuinely different finite-time linearization scales. Open
question, explicitly not resolved here: proceed with the 13-step window,
or reconsider whether a common linear-response comparison is the right
object at all.

Calibration cases (classes 0,3,7 + their specific nodes/states) are
reserved -- NOT to be reused in the eventual Stage 1 inferential sample.
