# Capacity Experiment: 20D vs 40D Readout

Findings: bonsai_capacity_experiment_findings.md

Key result: a second pruning threshold (0.95, alongside the primary 0.90)
does NOT beat generic dimensionality-inflation controls (duplicated
features, random projections) on either accuracy or diagnostic
correlations. A clean negative result for this specific hypothesis,
ruling out the cheapest next step before investing in richer graph
functionals (degree distributions, spectral features, community
structure).

Also includes: notMNIST "I"-outlier sensitivity analysis, which corrects
a previously-reported borderline finding (direct Bonsai-MLP confusion
agreement, p=0.051) that does not survive excluding the outlier class
(p=0.156 without it).
