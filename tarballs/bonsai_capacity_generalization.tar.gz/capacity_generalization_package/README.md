# Does the Capacity Experiment Generalize to a Second Dataset?

Findings: bonsai_capacity_generalization_findings.md

Headline: NO -- Fashion-MNIST's "combining thresholds is harmless" finding
does not hold on notMNIST, where the identical procedure collapses an 80%
classifier to 36% by causing it to never predict 6 of 10 classes. Five
candidate explanations were tested and ruled out; the mechanism remains
unidentified. This directly changes how the capacity-experiment series
should proceed -- every future combination experiment needs multi-dataset
validation before its conclusion is trusted.
