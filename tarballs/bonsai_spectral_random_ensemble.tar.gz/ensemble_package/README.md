# Random-Ensemble Verdict: Is Spectral Privileged or Generic?

Findings: bonsai_spectral_random_ensemble_findings.md

HEADLINE: dataset-dependent answer.
- Kuzushiji-MNIST: spectral beats ALL 100 random projections (100th
  percentile, p=0.0099, both raw and residualized). Specifically-spectral
  claim is strong here.
- Fashion-MNIST / notMNIST: spectral sits at 94-95th percentile, p=0.06-0.07
  (not significant). Broader capacity finding still holds, but whether
  spectral specifically (vs. any adequate alternative projection) is the
  privileged mechanism remains open on these two.

Also documents a full pipeline rebuild from scratch (environment reset
mid-session wiped all cached data) using a single fixed seed (42) across
every stochastic operation, per user request. Population statistics
rebuilt bit-identical to the original session, confirming the pipeline is
genuinely deterministic and reproducible from raw data + code alone.
