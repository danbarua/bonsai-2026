# Tarball contents — quick orientation

Start with `bonsai_audio_fresh_start_prompt.md` — that's the actual prompt,
paste its contents into the new chat.

- `complex_hopf_field.py`, `complex_hebbian_training.py` — reference code
  from the MNIST work. Reusable for the Hopf math; will need restructuring
  for audio's 1D/frequency-organized topology (see the prompt for why).
- `test_complex_hopf_field.py` — reference for testing STYLE only. It
  imports `mnist_loader`, `complex_edge_encoder`, `few_shot_harness`, and
  `maths.graphs` from the prior MNIST session, none of which are included
  here (they're MNIST-specific and not relevant to audio) — so this file
  won't run standalone as-is. Use it as a template for how to structure new
  audio-specific tests, not something to execute directly.
- `bonsai_complex_hopf_findings.md`, `bonsai_full_session_wrapup.md` — full
  prior context/findings, for reference.
