# Capacity Experiment III, Controlled: Spectral Findings

Findings: bonsai_spectral_controls_findings.md

HEADLINE: 20D+spectral significantly beats duplicate and shuffled-spectral
controls (consistent across 3 shuffle seeds) on all three primary
datasets -- but does NOT clearly beat a random-Gaussian control (p=0.06-0.19
everywhere), an honest disclosed complication.

THE DECISIVE TEST: residualized spectral (everything NOT linearly
predictable from 20D) still significantly improves classification on all
three primary datasets (p=0.036, 0.0002, 0.002) -- notMNIST recovers
essentially the entire original gain. This is the strongest, most direct
confirmation that spectral structure contains genuine information beyond
what 20D captures.

Mechanistic check: active-node-count confound is weak for Fashion-MNIST/
notMNIST but moderate for Kuzushiji-MNIST (r=0.635, class-level, n=10) --
flagged, not resolved.

MNIST deliberately not investigated further, per explicit instruction.
