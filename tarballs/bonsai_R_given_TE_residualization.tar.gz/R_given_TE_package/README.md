# R Residualized Against (T,E): Does the Third Channel Still Matter?

Findings: bonsai_R_given_TE_residualization_findings.md

HEADLINE: Extends the T-E residualization result to R. The decisive
comparison (T+E+full-R vs T+E+residual-R) shows residual-R is
STATISTICALLY INDISTINGUISHABLE from full-R on all three datasets
(p=0.21-0.83) -- confirming R's shared component with (T,E) contributes
little beyond what the residual alone provides. The T+E vs T+E+residual-R
comparison reaches clear significance only on Kuzushiji-MNIST (p=0.0103);
Fashion-MNIST and notMNIST are borderline (p=0.07-0.08), weaker support
than the equivalent E-against-T result.

HONEST COMPLICATION: unlike E's clean residualization, predicted-R shows
real (unexplained) movement on 2 of 3 datasets -- flagged, not smoothed
over, and specifically why the residual-vs-full comparison (not the
T+E-vs-predicted comparison) is the one this document relies on.
