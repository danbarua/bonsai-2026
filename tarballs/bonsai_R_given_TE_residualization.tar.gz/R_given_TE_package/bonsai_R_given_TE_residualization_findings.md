# Extending the Residualization Test: Is R Still Informative Given Both T and E?

## The question, and why it's sharper than residualizing against T alone

The final representation under consideration is (T, E, R), not just
(T, E). The natural extension of the T-E residualization test asks: after
topology matching *and* active-support overlap are both already
available, does R's remaining information still matter? R_perp =
R - ridge-predicted-R(T, E), compared against T+E, T+E+predicted-R,
T+E+residual-R, and T+E+full-R.

## Results

| Dataset | R² of R from (T,E) | T+E | T+E+predicted-R | T+E+residual-R | T+E+full-R | % of full-R gain recovered by residual |
|---|---|---|---|---|---|---|
| Fashion-MNIST | 0.556-0.844 | 74.40% | 75.80% | 77.00% | 77.40% | 86.7% |
| notMNIST | 0.425-0.754 | 83.60% | 86.20% | 85.60% | 86.80% | 62.5% |
| Kuzushiji-MNIST | 0.284-0.630 | 59.60% | 60.00% | 64.00% | 63.60% | 110.0% (see below) |

## An honest complication: unlike E's residualization, "predicted-R" shows real movement

In the T-E test, predicted-E never meaningfully beat T alone anywhere --
exactly as expected, since a linear classifier gains nothing from a
linear function of features it already has. Here, **predicted-R shows
non-trivial gains over T+E on two of three datasets** (Fashion-MNIST:
+1.4pp, notMNIST: +2.6pp) -- which should not happen for the same
mechanical reason, and is flagged rather than smoothed over. The likely
explanation is the one the review named for the smaller E-case deviations
(regularization geometry, numerical conditioning, or finite optimization
behavior as more correlated dimensions are added) operating more visibly
here, but this has not been independently confirmed, and the honest
position is that this specific condition's movement should not be
over-interpreted as a real information gain.

**This is exactly why the decisive comparisons are the other two, not
this one.**

## The two comparisons that actually matter

**T+E vs. T+E+residual-R** -- does R's non-(T,E)-predictable component add
real value:

| Dataset | McNemar p |
|---|---|
| Fashion-MNIST | 0.0725 (borderline, n.s.) |
| notMNIST | 0.0755 (borderline, n.s.) |
| **Kuzushiji-MNIST** | **0.0103** |

**T+E+full-R vs. T+E+residual-R** -- does the residual alone capture
essentially all of full R's value:

| Dataset | McNemar p |
|---|---|
| Fashion-MNIST | 0.824 (n.s.) |
| notMNIST | 0.210 (n.s.) |
| Kuzushiji-MNIST | 0.832 (n.s.) |

**The second comparison is the clean, decisive one, and it is
unambiguous: on every dataset, residual-R is statistically
indistinguishable from full R.** Whatever fraction of R overlaps with
(T,E) is contributing little beyond what the residual alone already
provides. The first comparison (whether adding residual-R meaningfully
beats T+E) reaches clear significance only on Kuzushiji-MNIST, with
Fashion-MNIST and notMNIST borderline -- weaker evidence than the
equivalent E-residualization result, but pointing the same direction
throughout.

**Kuzushiji-MNIST's "110%" figure** (residual-R's 64.00% slightly
exceeding full-R's 63.60%) should be read as noise around 100%, not a
literal claim that removing the shared component helps -- the two
conditions are statistically indistinguishable (p=0.832), so the modest
numerical excess is within ordinary variation, not a real "residual beats
full" effect.

## What this establishes, precisely

Consistent with, and extending, the T-E result: **after T and E are both
already available, R's component not linearly predictable from either
still carries most of R's incremental value**, most clearly on
Kuzushiji-MNIST (significant at the T+E-vs-residual level, not just the
residual-vs-full level) and directionally consistent but weaker on the
other two datasets. This is a real extension of the "variance overlap is
not proportional to predictive redundancy" lesson to the third channel,
though with less clean statistical support than the E-against-T result
provided -- the R-against-(T,E) test involves predicting a 10-dimensional
block from a 30-dimensional one (versus E's 10-from-20), a harder
regression problem with more room for the kind of implementation noise
flagged above.

## Honest limitations

- The predicted-R anomaly (real movement where none was mechanically
  expected) is reported and given a plausible explanation, not resolved.
  It does not affect the residual-vs-full comparison, which is the one
  this document leans on for its central claim.
- Fashion-MNIST and notMNIST's primary comparison (T+E vs. T+E+residual-R)
  does not reach conventional significance -- weaker support than
  Kuzushiji-MNIST's, and should be described as directionally consistent,
  not confirmed, on those two datasets.
- As with the T-E test, this residual is about linear recoverability
  specifically; nonlinear dependence between R and (T,E) is not removed
  and may still be substantial, consistent with the distance-correlation
  measurements.
- Ridge regularization strength (alpha=1.0) was not tuned, consistent
  with every other residualization in this project.

## Immediate next steps, per the review's recommended order

1. Global ink and class-independent energy controls (still the cheapest
   remaining test, still owed).
2. Frequency-band comparison with E held fixed.
3. If pursued further: residualizing E against both T and R jointly, to
   quantify each channel's unique linear contribution conditional on the
   other two -- the review's suggested complete conditional-residualization
   picture, of which this document completes the second of three possible
   pairings (E-given-T done previously, R-given-T,E done here, E-given-T,R
   remains).

## Reproducing these results

Ridge regression fit from concatenated (T,E) to R on training data for
each dataset; residual formed and evaluated identically to the T-E
residualization test. No new per-image computation required.
