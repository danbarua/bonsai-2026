# Final Control Layer: Is E+R About Correct Pairing or Just 40 Dimensions?

Findings: bonsai_ER_final_controls_findings.md

HEADLINE:
- notMNIST & Kuzushiji-MNIST: E+R beats EVERY dimensionality-matched
  control (duplicate-S, duplicate-R, S+random10D) AND both shuffle
  controls (scrambled E, scrambled R) -- comprehensive evidence the gain
  is genuinely about correct image-specific pairing, not just more
  dimensions.
- Fashion-MNIST: honest tension -- shuffle controls show correct pairing
  matters, but a generic random-10D addition actually beats E+R outright.
  Real effect, but not shown to be the best use of the extra dimensions
  there.
- Which component matters more is dataset-specific: R's correct pairing
  dominates on notMNIST (p=0.00075), E's correct pairing dominates on
  Kuzushiji-MNIST (p≈0.00000) -- consistent with KMNIST's known
  sensitivity to active-support energy specifically.

Next: class-independent global ink-energy control, then the redesigned
frequency-band ablation (E+R_band comparisons) on Kuzushiji-MNIST.
