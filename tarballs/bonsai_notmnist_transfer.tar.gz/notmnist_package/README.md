# notMNIST Transfer Experiment (Third Transfer Target)

Data: gzipped IDX files committed directly to the source repo, same
pattern as Fashion-MNIST:
```
for f in train-images-idx3-ubyte.gz train-labels-idx1-ubyte.gz t10k-images-idx3-ubyte.gz t10k-labels-idx1-ubyte.gz; do
  curl -sL -o $f "https://raw.githubusercontent.com/davidflanagan/notMNIST-to-MNIST/master/$f"
done
gunzip -k *.gz
```
Labels 0-9 correspond to letters A-J (font glyphs, not handwriting).

Pipeline code identical to every other frozen-configuration transfer
experiment. See bonsai_notmnist_findings.md for full results -- the
headline finding is a third, distinct pattern in the overlap-confusion
relationship: significant for the MLP, not for Bonsai's own classifier,
different again from both Fashion-MNIST (significant for both) and
Kuzushiji-MNIST (significant for neither).
