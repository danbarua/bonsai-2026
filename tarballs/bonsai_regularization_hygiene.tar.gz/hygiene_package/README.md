# Regularization-Hygiene Check: E Robust, R Weaker Than Stated

Findings: bonsai_regularization_hygiene_findings.md

HEADLINE: Rerunning both residualization tests on Kuzushiji-MNIST with
per-condition cross-validated regularization tuning and 3 ridge alphas:

- E-against-T: COMPLETELY ROBUST. Identical result (61.20% accuracy,
  p=4.39e-10) across all three ridge strengths, gain even LARGER than
  the original fixed-regularization test.
- R-against-(T,E): WEAKER THAN PREVIOUSLY STATED. The one significant
  result (p=0.0103 under fixed regularization) drops to borderline
  non-significance (p=0.0519) under tuned regularization. The predicted-R
  reparameterization artifact persists even under tuning (+0.8 to +1.2pp),
  confirming the review's mechanism is real, not just a fixed-C artifact.

This is a genuine downgrade to the R-against-(T,E) claim, applied
honestly rather than defended. E's finding is the robust one in this
project; R's conditional-residualization finding needs more support
before being stated with confidence.
