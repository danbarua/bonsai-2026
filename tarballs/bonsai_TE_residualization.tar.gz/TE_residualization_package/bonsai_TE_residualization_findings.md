# The T-E Residualization Test: Resolving the Dependence/Importance Tension, and It Generalizes

## The precise question this answers

Kuzushiji-MNIST showed an apparent tension: T and E are unusually strongly
dependent (dCor=0.860) while E's correct pairing is simultaneously the
single most important factor found anywhere in this line of work
(shuffling E there costs 6.06pp on average, with McNemar significance
levels as low as 1.0x10^-7). The review's proposed resolution: most of
E's variation overlaps T, but the small non-overlapping fraction carries
disproportionate discriminative value. Tested directly by fitting E from
T via ridge regression, forming the residual E_perp = E - Ê(T), and
comparing T alone, T+predicted-E, T+residual-E, and T+full-E.

## Result: confirmed, and not specific to Kuzushiji-MNIST

| Dataset | R² of E from T (range across dims) | T alone | T+predicted-E | T+residual-E | T+full-E | % of full-E gain recovered by residual alone |
|---|---|---|---|---|---|---|
| Fashion-MNIST | 0.702-0.809 | 70.00% | 70.60% | 73.60% | 74.40% | 81.8% |
| notMNIST | 0.368-0.393 | 79.40% | 79.20% | 83.00% | 83.60% | 85.7% |
| Kuzushiji-MNIST | 0.741-0.801 | 49.40% | 49.40% | 58.40% | 59.60% | **88.2%** |

**T+predicted-E never beats T alone** (identical on Kuzushiji-MNIST,
±0.6pp elsewhere) -- expected and reassuring: Ê(T) is a deterministic
linear function of T, so it contains no information a linear classifier
doesn't already have access to. All of the real gain comes from the
residual. **On every dataset, the residual alone recovers 82-88% of E's
full benefit**, despite R² of E from T varying enormously across datasets
(37-39% on notMNIST, 70-81% on Fashion-MNIST and Kuzushiji-MNIST). This is
not a Kuzushiji-MNIST-specific quirk -- it is a general property of how E
relates to T: E's classification value is concentrated in whatever
fraction is NOT linearly recoverable from T, regardless of how large or
small that fraction is in absolute terms.

## Statistical confirmation (T alone vs. T+residual-E)

| Dataset | McNemar p-value |
|---|---|
| Fashion-MNIST | 6.43x10^-3 |
| notMNIST | 3.93x10^-3 |
| Kuzushiji-MNIST | 2.15x10^-8 |

All three reach significance; Kuzushiji-MNIST's is dramatically stronger,
consistent with its outsized E-dependence found throughout this line of
work.

## The precise resolution of the apparent tension

Kuzushiji-MNIST's high T-E dCor (0.860) reflects that a large share of
E's *total variance* overlaps T -- true and confirmed directly (R²=0.74-0.80
here). But dependence measured over the whole block does not describe how
that dependence is distributed with respect to classification value. The
small residual fraction (roughly 20-26% of E's variance, by 1-R²) carries
the overwhelming majority of E's discriminative content (88.2% of its
total classification gain). High aggregate dependence and high residual
importance are not in tension once the aggregate is properly decomposed --
they describe different things (how much of E's variance is shared,
versus where E's label-relevant information is concentrated), and this
result shows precisely how both can be true at once.

## Honest limitations

- Ridge regression with a single untuned regularization strength
  (alpha=1.0), consistent with every other residualization in this
  project but not validated against alternatives.
- The T+predicted-E condition's near-zero gain is expected mechanically
  for a linear classifier reading a linear projection of T -- this
  confirms the decomposition is behaving as designed, not an independent
  finding.
- This resolves the dependence/importance tension descriptively; it does
  not explain *why* Kuzushiji-MNIST's overlap fraction is so much larger
  than notMNIST's, which remains an open, unexplained structural
  difference between the datasets' active-support geometry.

## Immediate next steps, per the review's recommended order

1. Global ink and class-independent energy controls (still owed).
2. Frequency-band comparison with E held fixed, now sharpened further:
   given this result, comparing T+E+R_band across bands should also track
   whether R's informative residual (relative to T) behaves the same way
   E's does.
3. Optionally, repeat the dCor measurements with T reduced to 10
   dimensions via PCA, to confirm the E,R-lowest-dependence ordering is
   not an artifact of T's larger dimensionality.

## Reproducing these results

Ridge regression (`sklearn.linear_model.Ridge`, alpha=1.0) fit from
existing cached T (20D topology-matching) to existing cached E
(active-support energy) on training data for each dataset; residual
formed and evaluated identically to prior residualization tests in this
project. No new per-image computation required.
