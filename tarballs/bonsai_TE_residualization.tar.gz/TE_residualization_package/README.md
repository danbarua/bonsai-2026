# T-E Residualization: Resolving the Dependence/Importance Tension

Findings: bonsai_TE_residualization_findings.md

HEADLINE: The apparent Kuzushiji-MNIST tension (high T-E dependence,
dCor=0.860, yet E's correct pairing is the single most important factor
found anywhere in this project) is precisely resolved and GENERALIZES to
all three datasets: T+predicted-E never beats T alone (mechanically
expected -- Ê(T) is a linear function of T, no new info for a linear
classifier), but T+residual-E recovers 82-88% of E's total gain on every
dataset, regardless of how much T-E overlap exists (37-39% R² on
notMNIST vs 70-81% on the other two). E's classification value is
concentrated in whatever fraction is NOT linearly recoverable from T.

Also incorporates precise corrections from review: softened claims about
CCA/dCor ordering (they diverge, and shouldn't be combined), corrected
"5-10 standard deviations" overclaim, added explicit standardization
statement, updated Stage C narrative to the sharper phrasing.
