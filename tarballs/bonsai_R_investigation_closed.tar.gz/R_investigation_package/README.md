# The R Investigation -- FINAL CLOSURE

Findings: bonsai_R_investigation_closed_findings.md

Both E and R are now closed at the exported-feature level, with the
statistical hierarchy, control logic, multiplicity treatment, and
architectural scoping fully calibrated across multiple rounds of review.

FINAL ENDPOINT: Oscillator specificity is unnecessary to explain the
observations. This is NOT the same as: the complete graph-generic
mechanism has been positively identified. The former is fully earned by
this investigation; the latter remains open.

Neither E nor R is retained as a preferred exported classifier feature.
Both remain open questions as intrinsic properties of the physical
dynamical system -- a genuinely different question from anything tested
in the feature-archaeology phase of this project.

NEXT: the actual research object -- computation performed by the
oscillator network's evolving physical state (diffusion, segmentation,
and the other candidates raised earlier), not another static feature
extracted from it.
