# E vs. Spatial Structure: Closed, With Correct Scope

Findings: bonsai_E_vs_spatial_residualization_findings.md

FINAL, CALIBRATED STATUS:

1. Oscillator-derived E significantly outperforms simple-E: nowhere.
2. Simple-E significantly outperforms E: nominally on Fashion-MNIST only,
   not robust to 6-comparison Bonferroni correction.
3. E and simple-E are statistically equivalent: NOT established (absence
   of evidence is not evidence of absence -- no equivalence margin,
   confidence interval, or non-inferiority test was run).
4. Kuzushiji-MNIST's residual difference (66.8% vs 65.2%, p=0.302):
   a numerical pattern, not an established effect.

CRITICAL SCOPING CORRECTION: "Retire E" means retire E from the DEFAULT
BENCHMARK FEATURE VECTOR for this digital classification pipeline. It
does NOT mean E has no justified role in any architecture. In a
biologically constrained, analog, or neuromorphic system, the relevant
comparison isn't "compute E vs compute G_spatial on a digital processor"
-- it may be "E emerges locally from ongoing dynamics" vs "G_spatial
requires explicit coordinates, global moments, multiplication, and
normalization." E as an intrinsic state variable of a physical dynamical
system remains an open, untested, and plausible question -- distinct
from E as an engineered feature for a linear classifier, which is now
closed.
