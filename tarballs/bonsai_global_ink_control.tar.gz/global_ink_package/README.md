# Global Ink Control: E vs. Generic Stroke Density

Findings: bonsai_global_ink_control_findings.md

HEADLINE: T+E significantly beats T+global-ink(10D, class-agnostic) on
ALL THREE datasets (p=1.0e-4 to 2.9e-3), with the gap widest on
Kuzushiji-MNIST. Generic ink stats do carry some real signal (+0.4 to
+3.8pp over T) but E captures substantially more everywhere.

Given R already present: E still significantly beats generic ink on
notMNIST (p=0.0039) and Kuzushiji-MNIST (p=0.0055) -- the same two
datasets where E's importance survived the regularization-hygiene audit.
Fashion-MNIST shows its familiar weaker pattern (global-ink+R
non-significantly edges out E+R).

CONCLUSION: E's established value is mechanistically confirmed as
class-specific support alignment, not a proxy for generic stroke density
-- on exactly the two datasets where E was already the most robust
finding in this project.
