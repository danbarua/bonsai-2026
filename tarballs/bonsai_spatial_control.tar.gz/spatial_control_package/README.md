# Spatial-Structure Control: A Significant Revision

Findings: bonsai_spatial_control_findings.md

HEADLINE: A class-agnostic control with genuine spatial structure
(quadrant energies, centroid, moments -- still zero class-conditioning)
MATCHES OR SLIGHTLY EXCEEDS E on every single dataset, including
Kuzushiji-MNIST where E's advantage over the simpler ink-amount control
was one of the most robust findings in the project (p=1.77e-06 -> gone
against this control).

REVISED CONCLUSION: E beating simple ink statistics was about spatial
information, not class-conditioning specifically. The claim "E's value
is about class-specific support alignment" is NOT supported once a
comparably spatial, still class-agnostic, control is used. This is a
genuine narrowing of a previously load-bearing mechanistic claim, applied
honestly rather than defended.

Does NOT undermine: E adding real value over T alone (established,
unaffected). DOES undermine: the specific "class-conditioning is what
matters" story for E's mechanism.

Flags: this same logic likely applies to the planned frequency-band
ablation for R -- worth considering before proceeding.
