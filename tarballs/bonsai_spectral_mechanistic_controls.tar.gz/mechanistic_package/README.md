# Mechanistic Controls: Normalized Energy + Random Orthonormal Basis

Findings: bonsai_spectral_mechanistic_controls_findings.md

HEADLINE:
- Fashion-MNIST/notMNIST: normalized spectral retains the full gain
  (genuine spectral shape matters, not just support overlap).
- Kuzushiji-MNIST: normalized spectral DECLINES (-1.2pp), and
  active-support-energy ALONE (no eigenvectors) performs as well as full
  spectral -- a real, disclosed mechanistic complication.
- BUT: Kuzushiji-MNIST's advantage survives the tighter active-support-
  matched random-basis control completely (100th percentile, 0/20
  matched) -- confirming it specifically needs the learned eigenstructure,
  not just support access. Both findings are true simultaneously without
  contradiction.

Next step: frequency-band ablation on Kuzushiji-MNIST (low- vs mid-
frequency vs random eigenvectors, matched dimensionality).
