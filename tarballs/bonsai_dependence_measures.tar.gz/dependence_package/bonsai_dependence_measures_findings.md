# Quantifying the Channels: Dependence Measures and the Decomposition Narrative

## Why this measurement matters, distinct from everything before it

Every prior result in this line of work demonstrated usefulness through
classifier performance -- accuracy, McNemar tests, oracle headroom. None
of it directly measured how statistically distinct the three channels
(T: topology matching, E: support energy, R: normalized spectral
allocation) actually are. This closes that gap using two complementary
measures: CCA (linear shared structure) and distance correlation (linear
and nonlinear dependence in one scalar).

## A necessary calibration step before interpreting anything

A synthetic sanity check surfaced a real methodological trap before real
data was touched: with a few hundred samples and ten dimensions, even
**genuinely independent** random blocks give a top canonical correlation
around 0.27 and a comparable distance correlation -- a well-known
finite-sample selection bias (the "top" canonical correlation is a
maximum over many directions, and it does not converge to zero just
because the true relationship is null). Every real measurement below is
therefore reported alongside a shuffled-null baseline (5 seeds, breaking
the pairing while preserving each block's own marginal structure) rather
than compared against a naive assumption that zero means independence.

## Results: all three pairs are genuinely, massively dependent -- but not equally

| Dataset | T,E: CCA (null) / dCor (null) | T,R: CCA (null) / dCor (null) | E,R: CCA (null) / dCor (null) |
|---|---|---|---|
| Fashion-MNIST | 0.966 (0.129) / 0.522 (0.080) | 0.900 (0.125) / 0.579 (0.110) | 0.832 (0.102) / 0.467 (0.089) |
| notMNIST | 0.771 (0.124) / 0.423 (0.087) | 0.834 (0.128) / 0.507 (0.123) | 0.815 (0.098) / 0.386 (0.081) |
| Kuzushiji-MNIST | 0.920 (0.119) / **0.860** (0.088) | 0.778 (0.125) / 0.513 (0.122) | 0.768 (0.102) / 0.310 (0.107) |

Every real value sits far above its corresponding null (typically 5-10
standard deviations of the null distribution) -- T, E, and R all share
substantial real structure with each other on every dataset. None of
these channels are anywhere close to independent in an absolute sense.

**But E,R consistently shows the lowest distance correlation of the three
pairs, on every single dataset** -- 0.467 vs. 0.522/0.579 (Fashion-MNIST),
0.386 vs. 0.423/0.507 (notMNIST), 0.310 vs. 0.860/0.513 (Kuzushiji-MNIST).
This is a clean, cross-dataset confirmation, independent of any classifier,
that E and R carry more statistically distinct information from each
other than either does from the original topology-matching
representation -- directly consistent with (though not fully explaining)
the classifier-based finding that separating them recovers value the
product S discards.

## A striking, dataset-specific finding worth flagging rather than explaining away

Kuzushiji-MNIST's T,E distance correlation (0.860) is far higher than the
same pair on either other dataset (0.522, 0.423) -- support energy and
topology-matching scores are unusually tightly linked there. This sits in
apparent tension with the earlier finding that E's *correct pairing*
matters more on Kuzushiji-MNIST than anywhere else (the largest, most
significant shuffle-sensitivity of any component on any dataset). These
are not actually contradictory: high dependence is not the same as
complete redundancy -- a dCor of 0.86 leaves real room for E to carry
additional information beyond what T captures, and the classifier
evidence indicates the model is using exactly that residual information.
This is offered as a resolution of an apparent tension, not a fully
explained mechanism, and is worth keeping in mind for any future
Kuzushiji-MNIST-specific mechanistic work.

## The reframed narrative, adopted directly

The three-stage structure proposed for this whole line of work is more
useful than the loose "experiment, then controls" framing this document's
history has drifted through, and is worth stating plainly:

- **Stage A -- does graph-spectral information exist beyond topology
  matching?** Yes (Capacity Experiment III's original result, confirmed
  across three datasets, one non-significant).
- **Stage B -- is the effect genuine?** Yes. It survives duplication,
  shuffling, residualization, random projections at matched dimensionality,
  and now direct dependence quantification -- not one of these controls
  produced a result inconsistent with a real effect on notMNIST and
  Kuzushiji-MNIST, and Fashion-MNIST's more limited status was itself
  confirmed consistently across every control, not contradicted by any of
  them.
- **Stage C -- what is the representation?** Not S = E×R. The
  representation is (T, E, R): topology matching, class-specific support
  overlap, and normalized graph organization, as three distinguishable
  channels the classifier benefits from receiving separately. The
  multiplicative product was an information-losing bottleneck, not the
  natural unit of representation.

**The central claim has shifted, and the shift is real, not just
rhetorical**: this is no longer primarily a claim about spectral features
being useful. It is a claim that a compressed statistic (S) was hiding two
separable channels whose separate identities carry more classification
value than their product -- a representational finding about information
compression, not a feature-engineering result specific to graph spectra.
Any classifier built on a similarly-compressed graph statistic may be
subject to the same loss.

## Honest limitations

- CCA and distance correlation are two specific dependence measures among
  many reasonable choices (the review also suggested HSIC and kernel
  alignment) -- consistent results between these two increases confidence
  but does not exhaust the space of ways to quantify dependence.
- Distance correlation was computed on an 800-sample subsample per
  dataset for computational tractability (O(n^2) cost) -- not the full
  ~3000-sample training set, though the shuffled-null comparison uses the
  identical subsampling procedure, keeping the comparison fair.
- The Kuzushiji-MNIST T-E dependence finding is reported and given a
  plausible resolution, not a tested mechanism -- it was not anticipated
  before running this measurement and has not been independently verified
  by a second method.
- The class-independent global ink-energy control and the redesigned
  frequency-band ablation (now cleanly formulated as (T,E,R_low) vs.
  (T,E,R_mid) vs. (T,E,R_high), with E held fixed per the review's
  updated design) remain the next steps and were not run in this pass.

## Reproducing these results

`dependence_measures.py` (new): `cca_canonical_correlations` and
`distance_correlation`, both verified against synthetic
independent/linearly-dependent/nonlinearly-dependent test cases before
use on real data. Applied to the existing cached T (20D topology-matching),
E (active-support energy), and R (normalized spectral allocation)
features for all three primary datasets, with a 5-seed shuffled-null
baseline computed identically for every comparison.
