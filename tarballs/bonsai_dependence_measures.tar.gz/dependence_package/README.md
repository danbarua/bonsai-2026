# Quantifying T, E, R Dependence Directly

Findings: bonsai_dependence_measures_findings.md

HEADLINE: Using CCA and distance correlation (both calibrated against a
shuffled-null baseline, since naive CCA/dCor show real finite-sample bias
at this sample size -- verified on synthetic data first), all three
channels (T=topology matching, E=support energy, R=normalized spectral
allocation) show massive real dependence on each other -- but E,R
consistently shows the LOWEST distance correlation of the three pairs, on
every single dataset. This is direct, classifier-independent evidence
that E and R carry more statistically distinct information from each
other than either does from T.

Also flags a striking, unexplained finding: Kuzushiji-MNIST's T-E
dependence (dCor=0.860) is far higher than on the other two datasets,
sitting in apparent (but resolvable) tension with E's outsized importance
there in the classifier-based shuffle tests.

Adopts the reframed three-stage narrative (Stage A: spectral info exists;
Stage B: effect is genuine; Stage C: representation is (T,E,R), not S=ExR)
as the organizing structure for this whole line of work going forward.
