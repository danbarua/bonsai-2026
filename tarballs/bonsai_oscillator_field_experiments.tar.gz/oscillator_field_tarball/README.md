# Bonsai Oscillator Field — Experiment Code

Code for everything in `bonsai_full_session_wrapup.md`, Parts 3 and 4 (the
new local oscillator-field model and its readout experiments). Requires the
real MNIST IDX files (`train-images.idx3-ubyte`, `train-labels.idx1-ubyte`,
`t10k-images.idx3-ubyte`, `t10k-labels.idx1-ubyte`) in a `mnist_data/`
subdirectory -- not included here (you already have them; not worth
redistributing).

## Core model

- `local_oscillator_field.py` -- the scalar oscillator field: local 4-neighbor
  coupling, closed-loop anchoring, partial-arc phase mapping, optional
  shared natural frequency (`omega`), first-spike-time tracking
  (`run_track_first_spike`) and full spike-train tracking
  (`run_track_spike_train`).
- `vector_oscillator_field.py` -- D=4 channel extension with cross-channel
  (skew-symmetric omega matrix) mixing, AKOrN/notebook-inspired.
- `hebbian_local_field.py` -- population-level Hebbian-adaptive local
  coupling (shared vertical/horizontal weights, unsupervised, no backprop).

## Baseline encoders (Part 2 of the wrap-up)

- `trivial_arc_encoder.py` -- cos/sin of raw pixel intensity, no simulation.
- `oscillator_field_encoder.py` -- converged phase-field encoder (the
  "does the dynamics do anything" test subject).
- `mnist_loader.py`, `few_shot_harness.py` -- pure-NumPy IDX loader and the
  encoding-/classifier-agnostic few-shot evaluation harness used throughout.

## Readout experiments (Part 4 of the wrap-up)

- `spike_time_encoder.py` -- first-spike-time readout. Needs `omega != 0`
  and the deterministic spatial phase gradient (`_phase_gradient`) for
  initialization -- see the module docstring for why (a real bug: uniform
  initialization gave zero variance across pixels).
- `spike_train_encoder.py` -- full spike-train cross-correlation coincidence
  graph (the CTM-inspired version), plus `spike_train_aligned_residual_signature`
  applying the same edge-extraction as below.
- `spectral_coincidence_encoder.py` -- temporal-coincidence graph (built from
  spike-time differences) + bare eigenvalue-spectrum feature.
- `self_gft_encoder.py` -- self-referential GFT (project a signal onto its
  own graph's eigenvectors) -- underperformed due to circularity, see
  `cross_signal_gft_encoder.py` for the version that breaks it.
- `cross_signal_gft_encoder.py` -- projects raw pixel intensity (not the
  signal that built the graph) onto the coincidence graph's eigenvectors.
- `resonance_classifier.py` -- per-class reference-graph resonance/matched-
  filter classifier. Decisively confounded (see wrap-up) -- kept for the
  documented negative result and the diagnostic pattern, not as something
  to build on directly.
- `shape_resonance_encoder.py` -- idealized geometric template (ring/
  vertical/horizontal/diagonal) resonance features -- same confound,
  confirmed a second way.
- `edge_encoder.py` / `edge_encoder_multi.py` -- **the best-performing
  result of the whole investigation**: subtract the low-frequency graph
  reconstruction from a signal, keep the residual (edges/boundaries, not
  overall resonance). `edge_encoder_multi.py` computes multiple `cutoff_idx`
  values efficiently from one eigendecomposition (for the parameter sweep);
  `edge_encoder.py` is the single-cutoff version.
- `diagnostic_encoders.py` -- two diagnostic controls: `pixel_direct_edge_encode`
  (bypasses the oscillator simulation entirely, to test whether it's
  discarding information -- it isn't, this does *worse*) and
  `aligned_plus_residual_encode` (concatenates the low-frequency component
  back in alongside the residual -- consistently better than residual alone).

## Dependencies

- `maths/` -- `GraphLaplacian` and spectral decomposition machinery, copied
  from the main Bonsai repo (`maths/graphs.py`, `maths/spectral.py`,
  `maths/core.py`), built and verified during the Bronski stability work
  earlier this project. `filter_signal()` (used by the edge-residual
  encoders) and `apply_gft()`/`project_signal()` (used by the GFT encoders)
  were sitting unused in this module until this investigation.

## Typical usage

```python
import numpy as np
from mnist_loader import load_idx_images, load_idx_labels
from edge_encoder_multi import edge_encode_multi_cutoff
from few_shot_harness import stratified_few_shot_sample
from sklearn.neighbors import NearestCentroid

X_train = load_idx_images('mnist_data/train-images.idx3-ubyte')
y_train = load_idx_labels('mnist_data/train-labels.idx1-ubyte')
X_train_flat = X_train.reshape(X_train.shape[0], -1).astype(np.float64) / 255.0

X_sub, y_sub = stratified_few_shot_sample(X_train_flat, y_train, n_per_class=10, seed=42)
features = edge_encode_multi_cutoff(X_sub, cutoffs=[22])[22]

clf = NearestCentroid()
clf.fit(features, y_sub)
```

Compute cost varies a lot by encoder -- the graph-spectral ones (edge,
spectral, GFT, resonance) each require an eigendecomposition of an (H*W,
H*W) = (784, 784) matrix per image, roughly 0.1-0.4s/image depending on
which variant. Cache test-set encodings once and reuse across classifier/
sample-size comparisons rather than re-encoding repeatedly -- see how each
sweep in the session was actually run for the pattern (encode once per
trial, loop classifiers over the cached result).
