# Stage 1B.2: One Blocking Issue Fixed, One Decision Pending

Findings: bonsai_stage1b_pilot_findings.md

BLOCKING ISSUE RESOLVED (with a decision needed): the design required
B_node as one of three balanced factors, but the calibration table had
locked a SINGLE node (median) -- making B_node uncomputable and
contradicting the design's own definition. Fixed by presenting the two
honest options:

  OPTION A (recommended): 3 nodes x 2 signs x 3 amplitudes = 18 inputs,
  432 total trials, ~4.8 hours. Matches the capability question as
  stated.

  OPTION B: 1 fixed node, redefined B=(B_sign+B_amplitude)/2, 144 trials,
  ~1.6 hours. Honest but narrower -- all node-discrimination claims
  removed.

DECISION NOT MADE UNILATERALLY -- awaiting confirmation given the real
cost difference.

OTHER FIXES APPLIED:
- tau/t notation: T=2.5 is now explicitly the POST-IMPULSE response
  horizon (elapsed time since t_p), not an absolute baseline endpoint --
  t_p=2.5 now has a genuine [2.5,5.0] response window, not zero.
- Nearby-state scale 0.1 RE-VERIFIED (new computation, this session)
  across all 4 perturbation-time states using the same 6 fixed replica
  directions -- max RMS 0.0085 (was tested at only 1 state before).
- Replica count clarified: R=6 means six PERTURBED replicas; the
  unperturbed reference is a separate diagnostic, not a 7th replica.
- Permutation algorithm corrected to preserve repeated-measures structure
  across replicas (was ambiguous/too restrictive before); unit-testing on
  synthetic data (identical maps -> Delta_map~0; separated maps ->
  clearly positive) now required before use on real data.
- Scope of inference made explicit: ONE baseline trajectory, four
  repeated states along it -- NOT four independent trajectories. Results
  reported by perturbation time AND pooled, not pooled only.

STATUS: Everything locked except the node-count decision. Ready to
execute immediately once that's confirmed.
