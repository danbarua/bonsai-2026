# Capacity Experiment III: Spectral Structure

Findings: bonsai_spectral_experiment_findings.md

HEADLINE: The first positive capacity result in this series. Spectral
alone is a weaker standalone readout than 20D or smoothness on every
dataset, but combining 20D+spectral gives statistically significant
improvements on 3 of 4 datasets (+4.0 to +6.8pp, McNemar p=0.0002-0.0055),
with the 4th showing the same direction without reaching significance.

Every complementarity diagnostic (prediction agreement, oracle headroom,
effective rank, cross-correlation) confirms spectral captures genuinely
more independent structure than smoothness did in Capacity Experiment II.

NEXT STEP BEFORE FULLY TRUSTING THIS: duplicated-feature and
random-feature controls have NOT yet been run for this result -- this is
flagged explicitly as the most important immediate follow-up, given how
large and significant this result is relative to everything else in the
series.

feature_provenance.py is the new engineering prerequisite (metadata +
validation) built to prevent the two prior normalization-state bugs from
recurring.
