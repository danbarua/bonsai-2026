# E/R Decomposition: A Cleaner Capacity Expansion

Findings: bonsai_spectral_ER_decomposition_findings.md

HEADLINE: The original unnormalized spectral score S = E*R (active-support
energy times normalized low-frequency energy fraction) was compressing
two complementary signals into one scalar per class. Giving the
classifier E and R as SEPARATE features (20D+E+R) significantly beats
20D+E, 20D+R, AND 20D+S individually on notMNIST (p=0.007-0.029) and
Kuzushiji-MNIST (p=0.00004-0.021). Fashion-MNIST shows a more limited
version (beats E only).

Also documents two corrections from the prior round: a floating-point
comparison bug (KMNIST random-basis "0 of 20" was actually "1 of 20",
a genuine tie) and a statistical overreach (Experiment 1's apparent
KMNIST-specific pattern does not survive paired McNemar testing --
neither difference is significant).

This is a genuine, no-new-computation improvement to the capacity
architecture, not just a mechanistic diagnostic.
