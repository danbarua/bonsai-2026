# Capacity Experiment II, Replicated Across Four Datasets

Findings: bonsai_smoothness_cross_dataset_findings.md

Headline: graph smoothness is a real, independently-effective readout on
ALL FOUR datasets tested (Fashion-MNIST, notMNIST, Kuzushiji-MNIST,
MNIST) -- never collapses to chance. But naive linear concatenation with
the original 20D representation NEVER produces a statistically detectable
improvement over the 20D baseline alone, on any dataset (McNemar
p=0.688-1.000 throughout). Effective rank of the combined 30D space is
consistently low (2.9-4.6 of 30 nominal dimensions) across all four
datasets, confirming substantial redundancy.

Decision, per the pre-specified rule: this justifies a nonlinear or
late-fusion experiment next, not a third graph functional or further
naive-concatenation replication.

Also documents a second data-integrity bug (MNIST 20D baseline collapsing
to exactly chance due to double-normalization of an already-normalized
cached file) caught and fixed using the same verification discipline
established in the prior notMNIST episode.
