# Fashion-MNIST Transfer Experiment

Download Fashion-MNIST (same IDX format as MNIST):
```
mkdir fashion_mnist_data && cd fashion_mnist_data
for f in train-images-idx3-ubyte.gz train-labels-idx1-ubyte.gz t10k-images-idx3-ubyte.gz t10k-labels-idx1-ubyte.gz; do
  curl -sL -o $f "https://raw.githubusercontent.com/zalandoresearch/fashion-mnist/master/data/fashion/$f"
done
gunzip -k *.gz
```

Then point `mnist_loader.load_idx_images`/`load_idx_labels` at the
resulting files instead of MNIST's. Pipeline code (developmental_pruning.py,
topology_matching_classifier.py) is unchanged from the frozen MNIST
configuration -- same threshold (0.9), same 20-feature (simple+cosine)
scoring, same LogisticRegression hybrid head.

See bonsai_fashion_mnist_findings.md for the full results.
