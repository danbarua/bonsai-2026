# Diffusion Stage 1A: CLOSED

Findings: bonsai_diffusion_stage1a_findings.md

STATUS: Formally closed, not extended. High evidence strength given the
extensive pre-inference validation (adaptive integration, independent
solver agreement, tangent-linear verification, coupling normalization,
multiplicity control).

CONCLUSION (precisely scoped): Under the infinitesimal-response
formulation, no statistically supported evidence that learned topology
produces distinguishable finite-time perturbation dynamics from the three
matched controls, over the 2.5-unit horizon tested.

IMPORTANT CLARIFICATION: this is NOT "the same pattern as E and R." Three
different substantive hypotheses were ruled out (E: spatial organization;
R: graph spectra; Stage 1A: first-order propagation dynamics) -- the
commonality is methodological rigor, not a repeated failure of the same
claim.

KEY OBSERVATION: the raw class-level data shows real dynamical diversity
(T, rewired, random, lattice all "win" on different classes) -- the null
result reflects inconsistency in which construction leads, not absence of
variation.

DECISION, reversing this document's earlier recommendation: do NOT extend
with more initial conditions -- that only narrows CIs around the same
estimand. NEXT: Stage 1B, finite-amplitude nonlinear response -- a
genuinely different question.

EMERGING PATTERN: interesting local behavior not aggregating into
population-level advantage for T over matched controls -- now observed
across E, R, and Stage 1A independently. Possibly one of this project's
most durable findings.
