# Full Distributional Evidence for E/R Decomposition

Findings: bonsai_ER_distributional_findings.md

HEADLINE:
- All 10 shuffle seeds (not 1 representative) now reported: E+R beats
  all 10 shuffled-R and all 10 shuffled-E conditions on every dataset.
- D statistic (per-seed, distributional): R-preservation consistently
  more valuable on Fashion-MNIST/notMNIST (D>0 all 10 seeds);
  E-preservation consistently more valuable on Kuzushiji-MNIST (D<0 all
  10 seeds).
- Proper 50-seed 20D random ensemble (matching E+R's actual size, not a
  single draw): E+R beats ALL 50 random draws on notMNIST and
  Kuzushiji-MNIST (p=0.0196 each) -- stronger and more decisive than the
  earlier single-draw comparison suggested. Fashion-MNIST remains
  non-significant (p=0.235), now confirmed robustly rather than from one
  draw.
- No p-values reported as "0.00000" -- exact scientific notation used
  throughout (e.g., Kuzushiji-MNIST E-shuffle: 1.0e-7 to 4.2e-5).
